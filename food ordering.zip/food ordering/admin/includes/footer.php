<div class="footer">
            
            <div>
                <strong>Copyright @</strong> Food Ordering System &copy; 2019-2020
            </div>
        </div>